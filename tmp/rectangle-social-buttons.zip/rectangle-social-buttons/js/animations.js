
$(document).ready(function() {
	$('.facebook').hover(function(event) {
		$('.pfacebook').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.facebook').mouseout(function(event) {
		$('.pfacebook').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.twitter').hover(function(event) {
		$('.ptwitter').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.twitter').mouseout(function(event) {
		$('.ptwitter').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.dribble').hover(function(event) {
		$('.pdribble').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.dribble').mouseout(function(event) {
		$('.pdribble').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.flickr').hover(function(event) {
		$('.pflickr').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.flickr').mouseout(function(event) {
		$('.pflickr').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.yahoo').hover(function(event) {
		$('.pyahoo').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.yahoo').mouseout(function(event) {
		$('.pyahoo').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.stumbleupon').hover(function(event) {
		$('.pstumbleupon').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.stumbleupon').mouseout(function(event) {
		$('.pstumbleupon').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.youtube').hover(function(event) {
		$('.pyoutube').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.youtube').mouseout(function(event) {
		$('.pyoutube').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.technorati').hover(function(event) {
		$('.ptechnorati').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.technorati').mouseout(function(event) {
		$('.ptechnorati').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.googleplus').hover(function(event) {
		$('.pgoogleplus').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.googleplus').mouseout(function(event) {
		$('.pgoogleplus').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.delicious').hover(function(event) {
		$('.pdelicious').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.delicious').mouseout(function(event) {
		$('.pdelicious').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.pinterest').hover(function(event) {
		$('.ppinterest').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.pinterest').mouseout(function(event) {
		$('.ppinterest').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.rss').hover(function(event) {
		$('.prss').animate(
			{ opacity: 1 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
	$('.rss').mouseout(function(event) {
		$('.prss').animate(
			{ opacity: 0 },
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			});
	});
});

